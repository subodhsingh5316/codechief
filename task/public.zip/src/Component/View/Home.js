import React from 'react'

class Home extends React.Component{
    render(){
        return(
            <React.Fragment>
            
            </React.Fragment>
        )
    }
} 